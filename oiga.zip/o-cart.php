<div class="bigline">
	<ul class="bradlinks">
		<li><a href="#"><i class="fa fa-angle-right"></i> Deporte y Rehabilitación</a></li>
		<li><a href="#"><i class="fa fa-angle-right"></i> Deporte y Rehabilitación</a></li>
	</ul>
    <div class="inside"><span>Carrito de compras</span></div>
</div>
<div class="cart trianglebg2">
    <table class="table table-hover table-prin">
        <tr>
            <th>Acciones</th>
            <th>Imagen</th>
            <th>Nombre del producto</th>
            <th>Unidad</th>
            <th>Talla</th>
            <th>Color</th>
            <th>Cantidad</th>
            <th>Precio Unit. (Sin Iva)</th>
            <th>Descuento</th>
            <th>Total</th>
        </tr>
        <tr>
            <td><a href="#"><i class="fa fa-remove"></i></td>
            <td><img src="/img/pro01.jpg" width="50"></td>
            <td>FIST AID KIT WATERPROOF</td>
            <td>1 UND.</td>
            <td>N/A</td>
            <td>Red</td>
            <td>1 UND.</td>
            <td>120.000</td>
            <td>40%</td>
            <td>$120.000</td>
        </tr>
        <tr>
            <td><a href="#"><i class="fa fa-remove"></i></td>
            <td><img src="/img/pro01.jpg" width="50"></td>
            <td>FIST AID KIT WATERPROOF</td>
            <td>1 UND.</td>
            <td>N/A</td>
            <td>Red</td>
            <td>1 UND.</td>
            <td>120.000</td>
            <td>40%</td>
            <td>$120.000</td>
        </tr>
        <tr>
            <td><a href="#"><i class="fa fa-remove"></i></td>
            <td><img src="/img/pro01.jpg" width="50"></td>
            <td>FIST AID KIT WATERPROOF</td>
            <td>1 UND.</td>
            <td>N/A</td>
            <td>Red</td>
            <td>1 UND.</td>
            <td>120.000</td>
            <td>40%</td>
            <td>$120.000</td>
        </tr>
        <tr>
            <td><a href="#"><i class="fa fa-remove"></i></td>
            <td><img src="/img/pro01.jpg" width="50"></td>
            <td>FIST AID KIT WATERPROOF</td>
            <td>1 UND.</td>
            <td>N/A</td>
            <td>Red</td>
            <td>1 UND.</td>
            <td>120.000</td>
            <td>40%</td>
            <td>$120.000</td>
        </tr>
    </table>
    <div class="row">
        <div class="col-sm-4 col-sm-offset-8">
            <div class="payable">
                <table class="table table-sec">
                    <tr>
                        <td>Sub Total antes de IVA.:</td>
                        <td>140.000</td>
                    </tr>
                    <tr>
                        <td>Total Ahorro:</td>
                        <td>120.000</td>
                    </tr>
                    <tr>
                        <td>IVA</td>
                        <td>20.000</td>
                    </tr>
                    <tr class="footing">
                        <td>Sub Total IVA incluido:</td>
                        <td>120.000</td>
                    </tr>
                </table>
                <p align="right">
                    <a href="#" class="btn btn-primary">Seguir Navegando</a>
                    <a href="#" class="btn btn-primary">Comprar</a>
                </p>
            </div>
        </div>
    </div>
</div>