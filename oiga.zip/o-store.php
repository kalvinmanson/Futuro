<div class="bigline">
	<ul class="bradlinks">
		<li><a href="#"><i class="fa fa-angle-right"></i> Deporte y Rehabilitación</a></li>
		<li><a href="#"><i class="fa fa-angle-right"></i> Deporte</a></li>
	</ul>
    <div class="inside"><span>Cuidados del Cuello</span></div>
</div>
<div class="filters">
    <h5>Filtrar por</h5>
    <div class="row">
        <div class="col-sm-4">
            <select class="form-control">
                <option>Categoría</option>
                <option>Valor 1</option>
                <option>Valor 2</option>
                <option>Valor 3</option>
            </select>
        </div>
        <div class="col-sm-4">
            <select class="form-control">
                <option>subcategoría</option>
                <option>Valor 1</option>
                <option>Valor 2</option>
                <option>Valor 3</option>
            </select>
        </div>
        <div class="col-sm-4">
            <select class="form-control">
                <option>Necesidad</option>
                <option>Valor 1</option>
                <option>Valor 2</option>
                <option>Valor 3</option>
            </select>
        </div>
    </div>
</div>
<div class="products">
    <div class="row">
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
    </div>
    <!-- row productos -->
    <p>&nbsp;</p>
    <div class="row">
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
    </div>
    <!-- row productos -->
    <p>&nbsp;</p>
    <div class="row">
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
    </div>
    <!-- row productos -->
    <p>&nbsp;</p>
    <div class="row">
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
        <div class="col-sm-4">
            <a href="#" class="product">
                <div class="discount">
                    <span>Descuento <strong>20%</strong></span>
                </div>
                <img src="/img/pro01.jpg" class="img-responsive">
                <div class="price">
                    Antes $ 68.585<br />
                    <span>Ahora <strong>$ 48.585</strong></span>
                </div>
            </a>
            <div class="productFooter">
                Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
            </div>
        </div>
    </div>
    <!-- row productos -->

</div>