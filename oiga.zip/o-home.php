<h1 class="bigtitle">Especializados en productos para el cuidado de la salud</h1>
<img src="/img/slides/home01.jpg" class="img-responsive">
<div class="promo">
	<img src="/img/promo-tit.jpg" class="img-responsive">
</div>
<div class="products">
	<div class="row">
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
	</div>
</div>
<img src="/img/slides/home02.jpg" class="img-responsive">
<div class="products">
	<div class="row">
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
		<div class="col-sm-3 col-xs-6">
			<a href="#" class="product">
				<div class="discount">
					<span>Descuento <strong>20%</strong></span>
				</div>
				<img src="/img/pro01.jpg" class="img-responsive">
				<div class="price">
					Antes $ 68.585<br />
					<span>Ahora <strong>$ 48.585</strong></span>
				</div>
			</a>
			<div class="productFooter">
				Aloevida AV:<br />Kit de limpieza facial<br />Ref 0247
			</div>
		</div>
	</div>
</div>