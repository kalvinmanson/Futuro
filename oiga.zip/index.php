<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Futuro</title>
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <link href="/css/font-awesome.min.css" rel="stylesheet">
    <link href="/css/slick.css?v=<?php echo rand(0,999999999999); ?>" rel="stylesheet">
    <link href="/css/slick-theme.css?v=<?php echo rand(0,999999999999); ?>" rel="stylesheet">
    <link href="/css/main.css?v=<?php echo rand(0,999999999999); ?>" rel="stylesheet">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <a href="#" class="facebookFixed"><i class="fa fa-facebook"></i></a>
    <div class="menus">
        <a href="#" class="tr_menuprin btn btn-primary btn-lg"><i class="fa fa-bars"></i></a>
    </div>
    <header>
      <div class="container">
        <div class="row">
          <div class="col-sm-5">
            <a href="/" class="logo">
              <img src="/img/logo.png" class="img-responsive">
            </a>
          </div>
          <div class="col-sm-7">
            <ul class="first-nav">
              <li><a href="#">Nosotros</a></li>
              <li><a href="#">Preguntas Frecuentes</a></li>
              <li><a href="#">Tiendas</a></li>
              <li><a href="#">Contactenos</a></li>
              <li><a href="#">Empleados</a></li>
            </ul>
            <div class="blockUser">
              <div class="row">
                <div class="col-sm-7">
                  <h3>Consulta online: 8:00 a.m. - 5:00 p.m.<br />
                  <img src="/img/icons/phone.png"> 635 5192</h3>
                  <form method="get" action="">
                    <div class="input-group">
                      <input type="text" class="form-control" placeholder="Search for...">
                      <span class="input-group-btn">
                        <button class="btn btn-primary" type="button">Buscar</button>
                      </span>
                    </div><!-- /input-group -->
                  </form>
                </div>
                <div class="col-sm-5">
                  <div class="infotop">
                    <div class="nombre">@NOMBRE</div>
                    <a href="#" class="btn btn-primary badge1">Mi cuenta</a> 
                    <a href="#" class="btn btn-primary badge1">Iniciar Sesión</a>
                    <div class="price">
                      <span class="cr1"><img src="/img/icons/shop.png"></span>
                      <span class="cr2"><strong>#02</strong></span>
                      <span class="cr3">$ 1.020.000</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div><!-- fin container -->
      <div class="menuprin">
        <div class="container">
          <ul class="nav nav-justified">
            <li>
              <a href="#">Cuidado <span>En casa</span></a>
              <div class="submenu">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Camas y Accesorios</a></li>
                    <li><a href="#">Sillas y Transporte</a></li>
                    <li><a href="#">Seguridad en el baño</a></li>
                    <li><a href="#">Diagnostico Incontinencia</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <a href="#">Deporte <span>y Rehabilitación</span></a>
              <div class="submenu">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Cuidado del Cuello</a></li>
                    <li><a href="#">Extremidades Superiores</a></li>
                    <li><a href="#">Extremidades inferiores</a></li>
                    <li><a href="#">Cuidado de Espalda</a></li>
                    <li><a href="#">Equipos de fisioterapia</a></li>
                    <li><a href="#">Linea Infantil</a></li>
                    <li><a href="#">Diagnostico Incontinencia</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <a href="#">Prevencion y <span>Cuidado de Varices</span></a>
              <div class="submenu">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Compresion Baja 8-15 MMHG</a></li>
                    <li><a href="#">Compresion Media 15-20 MMHG</a></li>
                    <li><a href="#">Compresion Firme 20-30 MMHG</a></li>
                    <li><a href="#">Compresion Extra-Firme 30-40 MMHG</a></li>
                    <li><a href="#">Media Antiembolicas 15-20 MMHG</a></li>
                    <li><a href="#">Linea Deportiva</a></li>
                    <li><a href="#">Linea Casual</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <a href="#">Cuidado <span>de Diabetes</span></a>
              <div class="submenu">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Glucometria</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <a href="#">Equipo <span>de Diagnostico</span></a>
              <div class="submenu">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Estetoscopios</a></li>
                    <li><a href="#">Esfigmomanometro</a></li>
                    <li><a href="#">Equipo de Diagnostico</a></li>
                    <li><a href="#">Monitoreo</a></li>
                    <li><a href="#">Instrumental</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <a href="#">Cuidado <span>Heridas</span></a>
              <div class="submenu">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Proteccion Esteril</a></li>
                    <li><a href="#">Irritación y Heridas</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li><a href="#">Cuidado de <span>Espalda y Pie</span></a></li>
            <li>
              <a href="#">Terapia <span>Respiratoria</span></a>
              <div class="submenu nega1">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Aspiradoras y Succionadores</a></li>
                    <li><a href="#">Cilindros de Oxigeno</a></li>
                    <li><a href="#">Concentradores</a></li>
                    <li><a href="#">Humidificadores</a></li>
                    <li><a href="#">Nebulizadores</a></li>
                    <li><a href="#">Maquinas CPAP</a></li>
                    <li><a href="#">Vaporizadores</a></li>
                  </ul>
                </div>
              </div>
            </li>
            <li>
              <a href="#">Alquiler <span>&nbsp;</span></a>
              <div class="submenu nega2">
                <div class="col-menu">
                  <ul>
                    <li><a href="#">Camas y Accesorios</a></li>
                    <li><a href="#">Movilidad y Transporte</a></li>
                    <li><a href="#">Equipo de Diagnostico</a></li>
                  </ul>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </header>
    <div class="container">
    <?php if(isset($_GET['o']) && is_file("o-".$_GET['o'].".php")) { 
        include("o-".$_GET['o'].".php");
      } else {
        include("o-home.php");
      } ?>
    </div>
<footer>
  <div class="bigline">
    <div class="container inside"><span>Nuestras Marcas</span></div>
  </div>

  <div class="container">

    <!-- Slick Carousel -->
    <div class="brands">
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
      <div><a href="#"><img src="/img/foot-logo.jpg" class="img-responsive"></a></div>
    </div>
      <!--/ Slick carouseñ-->

    <div class="row">
      <div class="col-sm-4">
        <div class="suscribe">
          <h4>¿Deseas recibir información acerca de nuestras promociones?</h4>
          <p>Ingresa tu e-mail</p>
          <form method="get" action="">
            <div class="input-group">
              <input type="text" class="form-control" placeholder="Email">
              <span class="input-group-btn">
                <button class="btn btn-primary" type="button">Enviar</button>
              </span>
            </div><!-- /input-group -->
          </form>

        </div>
      </div>
      <div class="col-sm-8">
        <div class="row">
          <div class="col-sm-3">
            <h4>Acerca de Nosotros</h4>
            <ul>
              <li><a href="#">Historia</a></li>
              <li><a href="#">Misión</a></li>
              <li><a href="#">Visión</a></li>
              <li><a href="#">Sugerencias</a></li>
            </ul>
          </div>
          <div class="col-sm-3">
            <h4>Centro de ayuda</h4>
            <ul>
              <li><a href="#">FAQ</a></li>
              <li><a href="#">Términos y condiciones</a></li>
              <li><a href="#">Habeas Data</a></li>
              <li><a href="#">Peticiones</a></li>
              <li><a href="#">Quejas y Reclamos</a></li>
            </ul>
          </div>
          <div class="col-sm-3">
            <h4>Donde Estamos</h4>
            <ul>
              <li><a href="#">Mapa de tiendas</a></li>
              <li><a href="#">Cotnacto</a></li>
            </ul>
            <h4>Micro Sites</h4>
            <ul>
              <li><a href="#">No-Varix</a></li>
              <li><a href="#">No-Varixx</a></li>
            </ul>
          </div>
          <div class="col-sm-3">
            <h4>Nuestros Productos</h4>
            <ul>
              <li><a href="#">Catalogo</a></li>
              <li><a href="#">Pasarela de pagos</a></li>
              <li><a href="#">Comparador</a></li>
              <li><a href="#">Ficha tecnica</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="ending">
    <a href="#" class="btn btn-primary outLine">Fuera De Linea</a>
    <p>Ortopedicos Futuro S.A.S.<br />Derechos reservados W360 2017</p>
  </div>
</footer>

    <script src="/js/jquery.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/slick.min.js?v=<?php echo rand(0,999999999999); ?>"></script>
    <script src="/js/main.js?v=<?php echo rand(0,999999999999); ?>"></script>
  </body>
</html>