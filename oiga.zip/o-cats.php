<div class="bigline">
	<ul class="bradlinks">
		<li><a href="#"><i class="fa fa-angle-right"></i> Deporte y Rehabilitación</a></li>
		<li><a href="#"><i class="fa fa-angle-right"></i> Deporte</a></li>
	</ul>
    <div class="inside"><span>Deporte y Rehabilitación</span></div>
</div>
<div class="cats">
    <div class="row">
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/01.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/02.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/03.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/04.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/05.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/06.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
        <div class="col-sm-3">
            <a href="#" class="cat">
                <img src="/img/cats/07.jpg" class="img-responsive">
                <h3>Cuidado del cuello</h3>
            </a>
        </div>
    </div>
</div>
